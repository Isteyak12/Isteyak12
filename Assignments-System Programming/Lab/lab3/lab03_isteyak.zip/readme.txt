//main.c
#include <stdio.h>
int increment(int a);
void main(void)
{
    int a;
    scanf("%i", &a);
    a = increment(a);
    printf("%i \n", a);
    return;
}

//increment.c
int increment(int a)
{
    int b = a;
    b = b + 1;
    return b;
}

shell cmd::
 626  powershell
  627  cat main.c
  628  ls
  629  rm main.exe
  630  ls
  631  touch hello.c
  632  cat hello.c
  633  ls
  634  rm hello.c
  635  ls
  636  cc main.c -S
  637  ls
  638  cat main.c
  639  cc main.c  -o main
  640  ls
  641  cc main.c  -o main
  642  cat main.c
  643  cc main.c  -o main
  644  cc main.c -S
  645  ls
  646  history
  647  vi main.s
  648  cc main.s -c
  649  ls
  650  vi main.o
  651  hexdump main.o
  652  ./main.o
  653  chmod +x main.o
  654  ls
  655  ./main.o
  656  cc main.o -o main
  657  ls
  658  ./main
  659  cc main.c -S
  660  vi main.s
  661  cat main.c
  662  cc main.c -S
  663  vi main.s
  664  cc main.c -S
  665  vi main.s
  666  ls
  667  cc main.o -o main
  668  ./main
  669  cc main.o -o main
  670  ./main
  671  ls
  672  cat increment.c
  673  ls
  674  cat output
  675  rm output
  676  ls
  677  cat main.c
  678  cat increment.c
  679  ls
  680  cat main.c
  681  cat increment.c
  682  cc main.c -S
  683  cc increment.c -S
  684  ls
  685  cc main.s -c
  686  cc increment.s -c
  687  ls
  688  cc main.o increment.o -o main
  689  ls
  690  ./main
  691  cat increment.c
  692  ls
  693  ./increment
  694  cc main.o increment.o -o main
  695  ls
  696  hexdump increment.o
  697  hexdump main.o
  698  ls
  699  cat increment.s
  700  cat main.s
  701  cat main.o
  702  hexdump increment.o
  703  history